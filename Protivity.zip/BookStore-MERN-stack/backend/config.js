export const PORT = 5555;

export const mongoDBURL = 
    'mongodb+srv://root:1234@book-store-mern.7uv7cpt.mongodb.net/books-collection?retryWrites=true&w=majority'
